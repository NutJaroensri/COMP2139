﻿namespace WebApplication2.Services
{
    public class IEmailSender
    {
    }
}
